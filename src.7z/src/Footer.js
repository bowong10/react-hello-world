import React from "react";

function Footer(){
    return (
        <div id="Footer">footer</div>   
    )
}
export default Footer;