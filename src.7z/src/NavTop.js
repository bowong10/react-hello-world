import React from "react";

function NavTop(){
    return (
        <div id="navtop">
            <ul>
                <li>Top Bar NAv</li>
                <li>Page1</li>
                <li>Page2</li>
                <li>Page3</li>
            </ul>
        </div>   
    )
}
export default NavTop;