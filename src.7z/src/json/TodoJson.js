const todoData = [
    {
        id: 1,
        text: "SASS",
        completed: false
    },
    {
        id: 2,
        text: "Git Hub Terminal",
        completed: true
    },
    {
        id: 3,
        text: "Atom Text Editor",
        completed: false
    },
    {
        id: 4,
        text: "Java New and Old differences",
        completed: false
    },
    {
        id: 5,
        text: "Laravel PHP thingy",
        completed: false
    },
    {
        id: 6,
        text: "NodeJS (sort of as not everywhere used it)",
        completed: false
    },
    {
        id: 7,
        text: "Java",
        completed: false
    },
    {
        id: 8,
        text: "GO",
        completed: false
    },
    {
        id: 9,
        text: "Javascript Framework - HyperAPP JS | ReactJS | Angular | Vue",
        completed: false
    }
]

export default todoData;