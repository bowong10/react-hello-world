import React from "react";

function MyInfo() {
    return (
            <div>
                <h1>Fiestar</h1>
                <p>Best song including I dont know, you are pitiful, one more</p>
                <p> Membmers as follow </p>
                <ul>
                    <li>Linzy</li>
                    <li>Jei</li>
                    <li>Hyemi</li>
                    <li>Yezi</li>
                    <li>Cao Lu</li>
                </ul>
            </div>
    )
}

export default MyInfo