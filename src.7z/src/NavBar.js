import React from "react";

function NavBar(){
    return (
        <div id="navbar">
            <ul>
                <li>Home</li>
                <li>Page1</li>
                <li>Page2</li>
                <li>Page3</li>
            </ul>
        </div>   
    )
}
export default NavBar;